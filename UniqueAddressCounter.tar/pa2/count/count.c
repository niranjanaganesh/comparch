#include <stdio.h>
#include <stdlib.h> 
#include "count.h" 
/*
 * PA2: Count Unique Addresses
 * This assignment is designed to use a hash table to count the number of unique addresses accessed
 * by a program. You need to implement a program called count. The input of the count program
 * is a trace consisting of 64-bit addresses and you are required to print out the number of unique
 * address in the trace.
 * */

void main(int argc, char* argv[])
{
	// prog variables  
	int hashtable_size = 1000;  
	long unsigned int address; 
	
	Node** hashtable = malloc(sizeof(Node*) * hashtable_size); 

	int count = 0;

	// file variables
	char* filename = argv[1]; 
	FILE* file; 
	file = fopen(filename, "r"); 
	
	// check if filename not passed in or file DNE  
	if(argc < 2 || file == NULL)
	{
		printf("error\n"); 
		return;
	} 
	// check if file is empty	
	fseek(file, 0, SEEK_END); 
	int size = ftell(file); 
	if(size == 0)
	{
		printf("0\n"); 
		return;	
	}
	rewind(file); 
	fopen(filename, "r"); 
	
	// read file line by line
	while(!feof(file))
	{
		fscanf(file, "%lx\n", &address); 
		// search hashtable 
		if(search(address, hashtable) == 0)
		{
		// if address not already in hashtable 
			insert(address, hashtable); 
			// add address to hashtable 
			count++; 
		}
	}
	printf("%d\n", count); 
	fclose(file);
	free(hashtable);
}
