#ifndef COUNT_H_
#define COUNT_H_

typedef struct Node
{
	long unsigned int data; 
	struct Node *next;
} Node; 

Node* create(long unsigned int data)
{
	// create new node
	Node* node = (struct Node*)malloc(sizeof(Node)); 
	
	// check if node is null 
	if(node == NULL)
	{
		exit(0); 
	}
	
	// set node values
	node->data = data; 
	node->next = NULL; 
	return node; 
}

int hash(long unsigned int address)
{
	int hashtable_size = 1000; 
	return address % hashtable_size; 
	//return 1; 
}


void insert(long unsigned int address, Node** hashtable)
{
	Node* node = create(address); 
	int key = hash(address); 	
	// slot is empty
	if(hashtable[key] == NULL)
	{
		hashtable[key] = node; 	
		return;
	}
	// slot is not empty 
	Node* head = hashtable[key]; 
	Node* current = head; 
	while(current->next != NULL)
	{
		current = current->next; 
	}
	current->next = node; 
	
}

int search(unsigned long address, Node** hashtable)
{
	// key is index of element with linked list with node with data 
	int key = hash(address); 
	//printf("key: %d\n", key);
	//printf("hashtable[key]->data: %s\n", hashtable[key]->data); 
	if(hashtable[key] != NULL)
	{
		Node* current = hashtable[key];
		while(current != NULL)
		{
			if(current->data == address)
			{
				return 1; 
			}
			current = current->next; 
		}
	}
	return 0; 
}

#endif // COUNT_H_
